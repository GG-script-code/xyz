



# Create sample data
dat <- mtcars[1:20, ]


warning("data not ready")



print(paste("Program2: Number of rows in cars", nrow(dat)))

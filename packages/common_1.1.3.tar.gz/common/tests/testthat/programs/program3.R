





dat <- mtcars[1:20, ]



print("Program3: Before Error")

stop("Here is an error")



print("Program3: After Error")





mn <- min(mtcars$mpg)

mx <- max(mtcars$mpg)

print(paste0("Program4: min of cars is ", mn))

print(paste0("Program4: max of cars is ", mx))

library(testthat)
library(fmdates)

test_check("fmdates")

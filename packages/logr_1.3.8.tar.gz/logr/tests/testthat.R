library(testthat)
library(logr)

test_check("logr")
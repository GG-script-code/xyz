
library(logr)

lf <- log_open()


log_print("Hello")


stop("stop me")
#warning("a warning message")

log_close()